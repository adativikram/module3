package com.src.dao;


import com.src.model.TdsMaster;

public interface TdsDAO {
	
	TdsMaster getDetailsById(int id);


}
