package com.src.controller;

import java.util.Date;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.src.model.ErrorInformation;
import com.src.utility.NoIdFoundException;


@ControllerAdvice
@RestController
public class ExceptionHandlerClass extends ResponseEntityExceptionHandler {
	@ExceptionHandler(value = NoIdFoundException.class)
	 public final ResponseEntity<ErrorInformation> handleNotFoundException(NoIdFoundException ex, WebRequest request) {
		com.src.model.ErrorInformation errorInformation = new ErrorInformation(new Date(), ex.getMessage(),
		        request.getDescription(false));
		    return new ResponseEntity<>(errorInformation, HttpStatus.NOT_FOUND);
	   }
	
}
