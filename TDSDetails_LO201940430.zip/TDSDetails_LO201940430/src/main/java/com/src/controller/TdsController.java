package com.src.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.src.model.TdsMaster;
import com.src.service.TdsService;
import com.src.utility.NoIdFoundException;

//it is combination od controller and responseBody
//it converts java objects to json and vice versa
@RestController  
public class TdsController {

	@Autowired // this is autowiring by name used for calling
	TdsService tdsService;

	
	//this is a default method
	//simply to check if application is working or no
	@RequestMapping("/")
	public String start() {

		return "application is running";
	}
	
	
	// this method is for retrieving a details using id
	//@RequestMapping(value = "/getByDetailsId", method = RequestMethod.GET) 	
	@GetMapping("/getByDetailsId")
	public TdsMaster getByPid(@RequestBody int id) throws NoIdFoundException {

		TdsMaster tdsmaster = tdsService.getDetailsById(id);
		if (tdsmaster == null) {
			throw new NoIdFoundException("ID not found Wrong ID:  " + id);
		} else
			return tdsmaster;

	}

}
