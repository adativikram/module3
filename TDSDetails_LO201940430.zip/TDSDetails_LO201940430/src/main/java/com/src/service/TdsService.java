package com.src.service;

import com.src.model.TdsMaster;

public interface TdsService {

	TdsMaster getDetailsById(int id);
}
