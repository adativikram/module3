package com.src.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.src.dao.TdsDAO;
import com.src.model.TdsMaster;

//auto-wiring is happening by name
@Component("incomeTaxService")
@Service
@Transactional
public class TdsServiceImpl implements TdsService {

	// this is autowiring by name used for calling
	@Autowired
	TdsDAO tdsDAO;
	@Override
	public TdsMaster getDetailsById(int id) {
		// TODO Auto-generated method stub
		return tdsDAO.getDetailsById(id);
	}

}
