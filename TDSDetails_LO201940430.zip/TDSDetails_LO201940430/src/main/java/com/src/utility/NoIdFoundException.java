package com.src.utility;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.NOT_FOUND)
public class NoIdFoundException extends Exception {
	
	public NoIdFoundException(String msg) {
		super(msg);
	}

}
